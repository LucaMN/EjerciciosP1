
import java.util.*;
/**
 * Esta clase se utiliza para probar algunos casos de la
 * clase Numero6E2D.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class PruebaNumero6E2D
{
    /**
     * Constructor de objetos de la clase PruebaNumero6E2D
     */
    public PruebaNumero6E2D()
    {
        // define e inicializa dos variables de tipo "Numero6E2D" 
        //invocando al constructor de la clase
        Numero6E2D n1 = new Numero6E2D();
        Numero6E2D n2 = new Numero6E2D();

        // invoca al método "asignarValor" para asignarle un valor
        // y evalúa por true o false el retorno
        asignarValor(n1, 123456.789);
        
        // invoca al método "valorAlmacenadoN1" para ver el valor almacenado
        valorAlmacenadoN1(n1);
        
        // invoca al método "asignarValor" para asignarle un valor
        // y evalúa por true o false el retorno
        asignarValor(n2, 1234567.89);
        // invoca al método "valorAlmacenadoN2" para ver el valor almacenado
        valorAlmacenadoN2(n2);
        
        // invoca al método "asignarValor" para asignarle un valor
        // y evalúa por true o false el retorno
        asignarValor(n2, -0.789);
        // invoca al método "valorAlmacenadoN2" para ver el valor almacenado
        valorAlmacenadoN2(n2);
        // define e inicializa una variables de tipo "Numero6E2D" 
        //invocando al constructor de la clase
        Numero6E2D n3 = new Numero6E2D();
        
        // invoca al método "asignarValorN3" de la variable n3, enviandole
        // la suma de los retornos del método "getNumero" de n1 y n2
        asignarValorN3( n1, n2, n3);
            
        mostrarLinea();
        
        // invoca al método "asignarValor" para asignarle un valor
        // y evalúa por true o false el retorno
        asignarValor(n1, -999999.989);
        // invoca al método "valorAlmacenadoN1" para ver el valor almacenado
        valorAlmacenadoN1(n1);
        // invoca al método "asignarValorN3" de la variable n3, enviandole
        // la suma de los retornos del método "getNumero" de n1 y n2
        asignarValorN3( n1, n2, n3);
            
        mostrarLinea();

        // utiliza la variable de clase "TOPE_MAXIMO" directamente desde
        // la clase porque es publica. Tambien podría utilizarse n1.TOPE_MAXIMO.
        // No es necesario crear instancias para usar estas variables.
        System.out.println("El tope máximo de la clase Numero6E2D es....: " 
                            + Numero6E2D.TOPE_MAXIMO);
        //Muestra una linea divisoria
        mostrarLinea();
        
        // invoca al método "asignarValor" para asignarle un valor
        // y evalúa por true o false el retorno
        asignarValor(n1, 1.0);
        // invoca al método "valorAlmacenadoN1" para ver el valor almacenado
        valorAlmacenadoN1(n1);
        
        // invoca al método "asignarValor" para asignarle un valor
        // y evalúa por true o false el retorno
        asignarValor(n2, 1.0);
        // invoca al método "valorAlmacenadoN2" para ver el valor almacenado
        valorAlmacenadoN2(n2);
        
        //Muestra el resultado de utilizar el metodo toString sobre el objeto
        toString(n1);
        toString(n2);
        
        mostrarLinea();
        
        //Compara si los dos objetos con iguales con un metodo equals
        compararEquals(n1, n2);
        
        mostrarLinea();
        
        //Compara si los dos objetos son iguales con "=="
        compararIgual(n1,n2);
        
        //Igualamos el objeto2 con el objeto1
        n2=n1;
        
        mostrarLinea();
        // invoca al método "valorAlmacenadoN2" para ver el valor almacenado
        valorAlmacenadoN2(n2);
        
        //Muestra el resultado de utilizar el metodo toString sobre el objeto
        toString(n1);
        toString(n2);
        
        mostrarLinea();
        
        //Compara si los dos objetos con iguales con un metodo equals
        compararEquals(n1, n2);
        
        mostrarLinea();
        
        //Compara si los dos objetos son iguales con "=="
        compararIgual(n1,n2);
    }
    
    private void valorAlmacenadoN1(Numero6E2D objeto){
        System.out.println("Valor almacenado en n1....: " + objeto.getNumero());
        
        System.out.println("-------------------------------------");
    }
    
    private void valorAlmacenadoN2(Numero6E2D objeto){
        System.out.println("Valor almacenado en n2....: " + objeto.getNumero());
        
        System.out.println("-------------------------------------");
    }
    
    private void asignarValor(Numero6E2D objeto, double numero){
        if (objeto.setNumero(numero)) {
            System.out.println("Pudo asignar el valor....: "+numero);
        } else {
            System.out.println("No pudo asignar el valor....: "+numero);
        }
    }
    
    private void asignarValorN3(Numero6E2D n1,Numero6E2D n2,Numero6E2D n3){
    if (n3.setNumero(n1.getNumero() + n2.getNumero())) {
            System.out.println("Resultado de la suma....: " + n3.getNumero());
        } else {
            System.out.println("No pudo asignar el resultado de la suma");
        }
    }
    
    private void mostrarLinea(){
        System.out.println("-------------------------------------");
    }
    
    private void toString(Numero6E2D objeto){
        System.out.println(objeto.toString());
    }
    private void compararIgual(Numero6E2D n1,Numero6E2D n2){
        if(n1==n2){
            System.out.println("Son iguales");
        }else{
            System.out.println("No son iguales");
        }
    }
    private void compararEquals(Numero6E2D n1,Numero6E2D n2){
        if(n1.equals(n2)){
            System.out.println("Son iguales");
        }else{
            System.out.println("No son iguales");
        }
    }
}
