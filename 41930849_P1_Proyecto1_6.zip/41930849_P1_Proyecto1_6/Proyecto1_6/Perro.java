

public class Perro
{
    private String nombre;
    private int edad;
    
    public Perro()
    {
        this.edad=0;
        this.nombre=null;
    }

    public void setNombre(String nombrePerro){
        nombre = nombrePerro;
    }
    public String getNombre(){
        return nombre;
    }
    
    public void setEdad(int edadPerro){
        edad = edadPerro;
    }
    public int getEdad(){
        return edad;
    }
}
