/**
 * Clase que cuenta con las caaracteristicas de un estudiante
 * 
 * @author Lucas Nuñez 
 * @version 1.0
 */
public class Estudiante
{
    private String  nombre;
    private int dni;
    private String fechaDeNacimiento;
    private String fechaDeIngreso;
    private String carrera;
    private int materiasAprobadas;
    private double cuota;

    /**
     * Constructor que inicializa una instancia de la clase
     */
    public Estudiante()
    {
        
        
    }
    /**
     * Metodo que permite ingresar un nombre
     * @param String nuevoNombre
     */
    public void setNombre(String nuevoNombre){
        this.nombre = nuevoNombre;
    }
    /**
     * Metodo que rotorna un nombre
     * @return String nombre
     */
    public String getNombre(){
        return nombre;
    }
    /**
     * Metodo que permite ingresar un  dni
     * @param int nuevoDni
     */
    public void setDni(int nuevoDni){
        this.dni = nuevoDni;
    }
    /**
     * Metodo que permite rotornar un dni
     * @return int dni
     */
    public int getDni(){
        return dni;
    }
    /**
     * Metodo que permite ingresar una fecha de nacimiento
     * @param String nuevaFecha
     */
    public void setFechaDeNacimiento(String nuevaFecha){
        this.fechaDeNacimiento = nuevaFecha;
    }
    /**
     * Metodo que retorna una fecha de nacimiento
     * @return String fechaDeNacimiento
     */
    public String getFechaDeNacimiento(){
        return fechaDeNacimiento;
    }
    /**
     * Metodo que permite ingresar una fecha de ingreso
     * @param String nuevaFechaDeIngreso
     */
    public void setFechaDeIngreso(String nuevaFechaDeIngreso){
        this.fechaDeIngreso = nuevaFechaDeIngreso;
    }
    /**
     * Metodo que retorna una fecha de ingreso
     * @return String fechaDeIngreso
     */
    public String getFechaDeIngreso(){
        return fechaDeIngreso;
    }
    /**
     * Metodo que permite ingresar el nombre de una carrera
     * @param String nombreCarrera
     */
    public void setCarrera(String nombreCarrera){
        this.carrera = nombreCarrera;
    }
    /**
     * Metodo que permite retornar el nombre de una carrera
     * @return String carrera
     */
    public String getCarrera(){
        return carrera;
    }
    /**
     * Metodo que permite ingresar materias aprobadas
     * @param int nuevasMaterias
     */
    public void setMateriasAprobadas(int nuevasMaterias){
        this.materiasAprobadas = nuevasMaterias;
    }
    /**
     * Metodo que permite retornar las materias aprobadas
     * @return int materiasAprobadas
     */
    public int getMateriasAprobadas(){
        return materiasAprobadas;
    }
    /**
     * Metodo que permite ingresar el valor de la cuota
     * @param double nuevasCuotas
     */
    public void setCuota(double nuevasCuotas){
        this.cuota = nuevasCuotas;
    }
    /**
     * Metodo que permite retornar el valor de una cuota
     * @return double cuota
     */
    public double getCuota(){
        return cuota;
    }
    
}
