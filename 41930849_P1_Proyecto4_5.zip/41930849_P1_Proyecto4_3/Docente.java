
/**
 * Clase docenten que cuenta con caracteristicas de un docente
 * 
 * @author Lucas Nuñez 
 * @version 1.0
 */
public class Docente
{
    private String  nombre;
    private int dni;
    private String fechaDeNacimiento;
    private String fechaDeIngreso;
    private String materia;
    private double sueldo;

    /**
     * Constructor que inicializa una instancia de la clase
     */
    public Docente()
    {
        
        
    }
    /**
     * Metodo que permite ingresar un nombre
     * @param String nuevoNombre
     */
    public void setNombre(String nuevoNombre){
        this.nombre = nuevoNombre;
    }
    /**
     * Metodo que rotorna un nombre
     * @return String nombre
     */
    public String getNombre(){
        return nombre;
    }
    /**
     * Metodo que permite ingresar un  dni
     * @param int nuevoDni
     */
    public void setDni(int nuevoDni){
        this.dni = nuevoDni;
    }
    /**
     * Metodo que permite rotornar un dni
     * @return int dni
     */
    public int getDni(){
        return dni;
    }
    /**
     * Metodo que permite ingresar una fecha de nacimiento
     * @param String nuevaFecha
     */
    public void setFechaDeNacimiento(String nuevaFecha){
        this.fechaDeNacimiento = nuevaFecha;
    }
    /**
     * Metodo que retorna una fecha de nacimiento
     * @return String fechaDeNacimiento
     */
    public String getFechaDeNacimiento(){
        return fechaDeNacimiento;
    }
    /**
     * Metodo que permite ingresar una fecha de ingreso
     * @param String nuevaFechaDeIngreso
     */
    public void setFechaDeIngreso(String nuevaFechaDeIngreso){
        this.fechaDeIngreso = nuevaFechaDeIngreso;
    }
    /**
     * Metodo que retorna una fecha de ingreso
     * @return String fechaDeIngreso
     */
    public String getFechaDeIngreso(){
        return fechaDeIngreso;
    }
    /**
     * Metodo que  permite ingresar una materia
     * @param String nombreMateria
     */
    public void setMateria(String nombreMateria){
        this.materia = nombreMateria;
    }
    /**
     * Metodo que retorna una materia
     * @return String materia
     */
    public String getMateria(){
        return materia;
    }
    /**
     * Metodo que permite ingresar un sueldo
     * @param double nuevoSueldo
     */
    public void setSueldo(double nuevoSueldo){
        this.sueldo = nuevoSueldo;
    }
    /**
     * Metodo que retorna un sueldo
     * @return double sueldo
     */
    public double getSueldo(){
        return sueldo;
    }
    
}
