
/**
 * Clase que tienen los atributos de un Administrativos
 * 
 * @author Lucas Nuñez 
 * @version 1.0
 */
public class Administrativo extends Persona
{
    private int horaDeEntrada;
    private int horaDeSalida;
    private double sueldo;
    /**
     * Constructor que crea una instancia de la clase Administrativo
     */
    public Administrativo()
    {
        super();
    }
    /**
     * Metodo que permite ingresar una hora de entrada
     * @param int nuevaHoraDeEntrada
     */
    public void setHoraDeEntrada(int nuevaHoraDeEntrada){
        this.horaDeEntrada = nuevaHoraDeEntrada;
    }
    /**
     * Metodo que retorna una hora de entrada
     * @return int horaDeEntrada
     */
    public int getHoraDeEntrada(){
        return horaDeEntrada;
    }
    /**
     * Metodo que permite ingresar una hora de salida
     * @param int horaDeSalida
     */
    public void setHoraDeSalida(int nuevaHoraDeSalida){
        this.horaDeSalida = nuevaHoraDeSalida;
    }
    /**
     * Metodo que retorna una hora de salida
     * @return int horaDeSalida
     */
    public int getHoraDeSalida(){
        return horaDeSalida;
    }
    /**
     * Metodo que permite ingresar un sueldo
     * @param double nuevoSueldo
     */
    public void setSueldo(double nuevoSueldo){
        this.sueldo = nuevoSueldo;
    }
    /**
     * Metodo que retorna un sueldo
     * @return double sueldo
     */
    public double getSueldo(){
        return sueldo;
    }
}
