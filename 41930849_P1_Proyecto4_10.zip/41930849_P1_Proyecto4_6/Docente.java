
/**
 * Clase docenten que cuenta con las caracteristicas de un docente
 * 
 * @author Lucas Nuñez 
 * @version 1.0
 */
public class Docente extends Persona
{
    private String materia;
    private double sueldo;

    /**
     * Constructor que inicializa una instancia de la clase
     */
    public Docente()
    {
        super();
        
    }
    /**
     * Metodo que  permite ingresar una materia
     * @param String nombreMateria
     */
    public void setMateria(String nombreMateria){
        this.materia = nombreMateria;
    }
    /**
     * Metodo que retorna una materia
     * @return String materia
     */
    public String getMateria(){
        return materia;
    }
    /**
     * Metodo que permite ingresar un sueldo
     * @param double nuevoSueldo
     */
    public void setSueldo(double nuevoSueldo){
        this.sueldo = nuevoSueldo;
    }
    /**
     * Metodo que retorna un sueldo
     * @return double sueldo
     */
    public double getSueldo(){
        return sueldo;
    }
    
}
