/**
 * Clase que cuenta con las caaracteristicas de un estudiante
 * 
 * @author Lucas Nuñez 
 * @version 1.0
 */
public class Estudiante extends Persona
{
    private String carrera;
    private int materiasAprobadas;
    private double cuota;

    /**
     * Constructor que inicializa una instancia de la clase
     */
    public Estudiante()
    {
       super();
        
    }
    /**
     * Metodo que permite ingresar el nombre de una carrera
     * @param String nombreCarrera
     */
    public void setCarrera(String nombreCarrera){
        this.carrera = nombreCarrera;
    }
    /**
     * Metodo que permite retornar el nombre de una carrera
     * @return String carrera
     */
    public String getCarrera(){
        return carrera;
    }
    /**
     * Metodo que permite ingresar materias aprobadas
     * @param int nuevasMaterias
     */
    public void setMateriasAprobadas(int nuevasMaterias){
        this.materiasAprobadas = nuevasMaterias;
    }
    /**
     * Metodo que permite retornar las materias aprobadas
     * @return int materiasAprobadas
     */
    public int getMateriasAprobadas(){
        return materiasAprobadas;
    }
    /**
     * Metodo que permite ingresar el valor de la cuota
     * @param double nuevasCuotas
     */
    public void setCuota(double nuevasCuotas){
        this.cuota = nuevasCuotas;
    }
    /**
     * Metodo que permite retornar el valor de una cuota
     * @return double cuota
     */
    public double getCuota(){
        return cuota;
    }
    
}
