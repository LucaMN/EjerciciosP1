
/**
 * Clase que contiene los atributos de un Directivo
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class Directivo extends Empleado
{
    private String cargoActual;

    /**
     * Constructor que inicializa una instancia de la clase Directivo
     */
    public Directivo()
    {
        super();
    }
    /**
     * Metodo que permite ingresar un nuevo cargo
     * @param String nuevoCargo
     */
    public void setCargoActual(String nuevoCargo){
        this.cargoActual = nuevoCargo;
    }
    /**
     * Metodo que retorna el cargo actual
     * @return String cargoActual
     */
    public String getCargoActual(){
        return cargoActual;
    }
    
}
