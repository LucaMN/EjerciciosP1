
/**
 * Esta clase permitirá modelar un empleado 
 * administrativo, utiliza
 * como superclase a la clase Empleado.
 * 
 * @author (Mario Finos) 
 * @version (V2)
 */
public class Administrativo extends Empleado
{
    // definición de variables de instancia
    private int horaEntrada;
    private int horaSalida;
    private static final String QUE_SOY = "Administrativo";
    /**
     * Constructor de objetos de la clase Administrativo
     */
    public Administrativo()
    {
        super();
    }

    /**
     * Método setHoraEntrada
     * 
     * @param  int horaEntrada La hora de entrada del administrativo
     */
    public void setHoraEntrada(int horaEntrada)
    {
        this.horaEntrada = horaEntrada;
    }

    /**
     * Método setHoraSalida
     * 
     * @param  int horaSalida La hora de salida del administrativo
     */
    public void setHoraSalida(int horaSalida)
    {
        this.horaSalida = horaSalida;
    }

    
    /**
     * Método getHoraEntrada
     * 
     * @return  int  La hora de entrada del administrativo
     */
    public int getHoraEntrada()
    {
        return horaEntrada;
    }

    /**
     * Método getHoraSalida
     * 
     * @return  int  La hora de salida del administrativo
     */
    public int getHoraSalida()
    {
        return horaSalida;
    }    
    
    /**
     * Método que retorna los datos de un administrativo.
     * @Override
     * @return String
     */
    public String toString() {
        System.out.println(super.toString());
        return "Hora de entrada: "+this.horaEntrada+'\n'+"Hora de salida: "+this.horaSalida+'\n';
    }
    
    /**
     * Método que retorna el tipo de persona.
     * @return String QUE_SOY;
     * @Override
     */
    public String queSoy()
    {
        return this.QUE_SOY;
    }
}