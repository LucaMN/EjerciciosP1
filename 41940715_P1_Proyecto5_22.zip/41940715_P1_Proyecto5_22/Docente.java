
/**
 * Esta clase permitirá modelar un docente,utiliza
 * como superclase a la clase Empleado.
 * 
 * @author (Mario Finos) 
 * @version (V2)
 */
public class Docente extends Empleado
{
    // definición de variables de instancia
    private String materia;
    private static final String QUE_SOY = "Docente";
    /**
     * Constructor de objetos de la clase Docente
     */
    public Docente()
    {
        super();
    }

    /**
     * Método setMateria
     * 
     * @param  String materia La materia que dicta el docente
     */
    public void setMateria(String materia)
    {
        this.materia = materia;
    }
    
    /**
     * Método getMateria
     * 
     * @return  String  La materia que dicta el docente
     */
    public String getMateria()
    {
        return materia;
    }
    
    /**
     * Método que retorna los datos de un docente.
     * @Override
     * @return String
     */
    public String toString() {
        System.out.println(super.toString());
        return "Materia Dictada: "+this.materia+'\n';
    }
    
    /**
     * Método que retorna el tipo de persona.
     * @return String QUE_SOY
     * @Override
     */
    public String queSoy()
    {
        return this.QUE_SOY;
    }
}
