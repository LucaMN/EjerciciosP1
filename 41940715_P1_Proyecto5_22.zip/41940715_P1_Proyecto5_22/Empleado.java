/**
 * La clase Empleado deriva de Persona y permitirá
 * agrupar a todas las personas que cobran sueldo 
 * (administrativos, docentes, etc.).
 * 
 * @author (Mario Finos) 
 * @version (V1)
 */
public class Empleado extends Persona
{
    // definición de variables de instancia
    private double sueldoMensual;
    private static final String QUE_SOY = "Empleado";
    /**
     * Constructor de objetos de la clase Empleado
     */
    public Empleado()
    {
        super();
    }
    
    /**
     * Método setSueldoMensual
     * 
     * @param  double sueldoMensual El sueldo mensual del docente
     */
    public void setSueldoMensual(double sueldoMensual)
    {
        this.sueldoMensual = sueldoMensual;
    }

    
    /**
     * Método getSueldoMensual
     * 
     * @return  double  El sueldo mensual del docente
     */
    public double getSueldoMensual()
    {
        return sueldoMensual;
    } 
    
    /**
     * Método que retorna los datos de un empleado.
     * @Override
     * @return String
     */
    public String toString() {
        System.out.println(super.toString());
        return "Sueldo Mensual: "+this.sueldoMensual;
    }
    
    /**
     * Método que retorna el tipo de persona.
     * @return String QUE_SOY
     * @Override
     */
    public String queSoy()
    {
        return this.QUE_SOY;
    }
}