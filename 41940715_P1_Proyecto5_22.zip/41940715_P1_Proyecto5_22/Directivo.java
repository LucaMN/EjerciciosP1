/**
 * Esta clase permitirá modelar un empleado 
 * directivo, utiliza
 * como superclase a la clase Empleado.
 * 
 * @author (Mario Finos) 
 * @version (V2)
 */
public class Directivo extends Empleado
{
    // definición de variables de instancia
    private String cargo;
    private static final String QUE_SOY = "Directivo";
    /**
     * Constructor de objetos de la clase Directivo
     */
    public Directivo()
    {
        super();
    }

    /**
     * Método setCargo
     * 
     * @param  String cargo El cargo que ocupa el directivo
     */
    public void setCargo(String cargo)
    {
        this.cargo = cargo;
    }

    
    /**
     * Método getCargo
     * 
     * @return  String  El cargo que ocupa el directivo
     */
    public String getCargo()
    {
        return cargo;
    }
        
    /**
     * Método que retorna los datos de un directivo.
     * @Override
     * @return String
     */
    public String toString() {
        System.out.println(super.toString());
        return "Cargo: "+this.cargo+'\n';
    }
    
    /**
     * Método que retorna el tipo de persona.
     * @return String QUE_SOY
     * @Override
     */
    public String queSoy()
    {
        return this.QUE_SOY;
    }
}
