
/**
 *Clase que sirve para probar el funcionamiento de la clase MiInstituto.
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class PruebaMiInstituto
{
    /**
     * Constructor que realiza pruebas de la clase MiInstituto
     */
    public PruebaMiInstituto()
    {
        //Definimos una variable de tipo MiInstituto
        MiInstituto prueba1 = new MiInstituto();
        
        //Definimos 3 variables de tipo Docente
        Docente docente1 = new Docente();
        docente1.setNombre("Raul");
        docente1.setDni(41789526);
        docente1.setFechaDeNacimiento("1/2/1966");
        docente1.setFechaDeIngreso("4/5/2007");
        docente1.setSueldo(20000);
        docente1.setMateria("Matematica");
        
        Docente docente2 = new Docente();
        docente2.setNombre("Roca");
        docente2.setDni(41788226);
        docente2.setFechaDeNacimiento("11/12/1965");
        docente2.setFechaDeIngreso("3/7/2010");
        docente2.setSueldo(2500);
        docente2.setMateria("Lengua");
        
        Docente docente3 = new Docente();
        docente3.setNombre("Ramon");
        docente3.setDni(44778226);
        docente3.setFechaDeNacimiento("21/5/1967");
        docente3.setFechaDeIngreso("4/5/2018");
        docente3.setSueldo(5000);
        docente3.setMateria("Literatura");
        //Definimos 2 variables de tipo directivo
        Directivo directivo1 = new Directivo();
        directivo1.setNombre("Ricardo");
        directivo1.setDni(96385274);
        directivo1.setFechaDeNacimiento("22/11/1978");
        directivo1.setFechaDeIngreso("27/11/1986");
        directivo1.setSueldo(35000);
        directivo1.setCargoActual("Director");
        
        Directivo directivo2 = new Directivo();
        directivo2.setNombre("Coco");
        directivo2.setDni(43738236);
        directivo2.setFechaDeNacimiento("22/4/1985");
        directivo2.setFechaDeIngreso("14/5/1977");
        directivo2.setSueldo(25000);
        directivo2.setCargoActual("Subdirector");
        
        //Definimos 2 variables de tipo directivo
        Administrativo administrativo1 = new Administrativo();
        administrativo1.setNombre("Monica");
        administrativo1.setDni(73737276);
        administrativo1.setFechaDeNacimiento("7/7/1977");
        administrativo1.setFechaDeIngreso("17/1/2007");
        administrativo1.setSueldo(25700);
        administrativo1.setHoraDeEntrada(14);
        administrativo1.setHoraDeSalida(20);
        
        Administrativo administrativo2 = new Administrativo();
        administrativo2.setNombre("Maria");
        administrativo2.setDni(7753146);
        administrativo2.setFechaDeNacimiento("9/7/1997");
        administrativo2.setFechaDeIngreso("6/1/2009");
        administrativo2.setSueldo(26700);
        administrativo2.setHoraDeEntrada(17);
        administrativo2.setHoraDeSalida(21);
        //Definimos 5 variables de tipo estudiante
        Estudiante estudiante1 = new Estudiante();
        estudiante1.setNombre("Lulu");
        estudiante1.setDni(12375698);
        estudiante1.setFechaDeNacimiento("28/9/2001");
        estudiante1.setFechaDeIngreso("16/11/2021");
        estudiante1.setCarrera("Lengua");
        estudiante1.setMateriasAprobadas(1);
        estudiante1.setCuota(24001);
        
        Estudiante estudiante2 = new Estudiante();
        estudiante2.setNombre("Lala");
        estudiante2.setDni(22222222);
        estudiante2.setFechaDeNacimiento("2/2/2002");
        estudiante2.setFechaDeIngreso("2/2/2022");
        estudiante2.setCarrera("Fisica");
        estudiante2.setMateriasAprobadas(1);
        estudiante2.setCuota(24002);
        
        Estudiante estudiante3 = new Estudiante();
        estudiante3.setNombre("Lele");
        estudiante3.setDni(33333333);
        estudiante3.setFechaDeNacimiento("13/23/2003");
        estudiante3.setFechaDeIngreso("13/3/2023");
        estudiante3.setCarrera("Lengua");
        estudiante3.setMateriasAprobadas(1);
        estudiante3.setCuota(24003);
        
        Estudiante estudiante4 = new Estudiante();
        estudiante4.setNombre("Lili");
        estudiante4.setDni(44444444);
        estudiante4.setFechaDeNacimiento("24/4/2004");
        estudiante4.setFechaDeIngreso("14/4/2024");
        estudiante4.setCarrera("Fisica");
        estudiante4.setMateriasAprobadas(5);
        estudiante4.setCuota(24004);
        
        Estudiante estudiante5 = new Estudiante();
        estudiante5.setNombre("Lolo");
        estudiante5.setDni(55555555);
        estudiante5.setFechaDeNacimiento("25/5/2005");
        estudiante5.setFechaDeIngreso("15/5/2025");
        estudiante5.setCarrera("Fisica");
        estudiante5.setMateriasAprobadas(5);
        estudiante5.setCuota(24005);
        //Agregamos 3 docentes a la lista
        prueba1.agregarDocente(docente1);
        prueba1.agregarDocente(docente2);
        prueba1.agregarDocente(docente3);
        //Agregamos 2 directivos a la lista
        prueba1.agregarDirectivo(directivo1);
        prueba1.agregarDirectivo(directivo2);
        //Agregamos 2 administrativos a la lista
        prueba1.agregarAdministrativo(administrativo1);
        prueba1.agregarAdministrativo(administrativo2);
        //Agregamos 5 estudiantes a la lista
        prueba1.agregarEstudiante(estudiante1);
        prueba1.agregarEstudiante(estudiante2);
        prueba1.agregarEstudiante(estudiante3);
        prueba1.agregarEstudiante(estudiante4);
        prueba1.agregarEstudiante(estudiante5);
        //Listamos los datos de las 4 listas
        prueba1.imprimirTodosLosDatos();
        //listamos la cantidad de elementos de cada una de las 4 listas.
        prueba1.imprimirCantidadDePersonasPorRol();
        //listamos la cantidad de estudiantes discriminadospor la cantidad de materias aprobadas que tienen
        prueba1.imprimirCantidadDeEstudiantesPorMatAprob();
    }

    
}
