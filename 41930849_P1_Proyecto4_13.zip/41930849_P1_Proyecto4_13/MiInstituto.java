import java.util.*;
/**
 * Permita almacenar en 4 listas todas las personas(directivos, docentes, administrativos y estudiantes).
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class MiInstituto
{
    private ArrayList<Directivo> directivos;
    private ArrayList<Docente> docentes;
    private ArrayList<Administrativo> administrativos;
    private ArrayList<Estudiante> estudiantes;
    /**
     * Constructor que inicializa las 4 listas
     */
    public MiInstituto()
    {
        directivos = new ArrayList();
        docentes = new ArrayList();
        administrativos = new ArrayList();
        estudiantes = new ArrayList();
    }
    /**
     * Recibe un objeto de la clase correspondiente y lo agregua la lista respectiva.
     * @param Estudiante estudiante
     */
    public void agregarEstudiante(Estudiante estudiante){
        estudiantes.add(estudiante);
    }
    /**
     * Recibe un objeto de la clase correspondiente y lo agregua la lista respectiva.
     * @param Administrativo administrativo
     */
    public void agregarAdministrativo(Administrativo administrativo){
        administrativos.add(administrativo);
    }
    /**
     * Recibe un objeto de la clase correspondiente y lo agregua la lista respectiva.
     * @param Docente docente
     */
    public void  agregarDocente(Docente docente){
        docentes.add(docente);
    }
    /**
     * Recibe un objeto de la clase correspondiente y lo agregua la lista respectiva.
     * @param Directivo directivo
     */
    public void agregarDirectivo(Directivo directivo){
        directivos.add(directivo);
    }
    /**
     * Permite imprimir la cantidad de directivos, estudiantes, docentes y administrativos
     * almacenados en las listas.
     */
    public void imprimirCantidadDePersonasPorRol(){
        System.out.println("La cantidad de estudiantes es: "+estudiantes.size());
        System.out.println("La cantidad de administrativos es: "+administrativos.size());
        System.out.println("La cantidad de docentes es: "+docentes.size());
        System.out.println("La cantidad de directivos es: "+directivos.size());
    }
    /**
     * Permite imprimir todos los datos de todas las personas, recorriendo cada una de las listas.
     */
    public void imprimirTodosLosDatos(){
        System.out.println("Datos de las personas: ");
        System.out.println("Estudiantes:");
        for(Estudiante estudiante : estudiantes){
            imprimirDatosPersona(estudiante);
            System.out.println(" carrera: "+estudiante.getCarrera()+" materiasAprobadas: "+estudiante.getMateriasAprobadas()
            + " cuota: "+estudiante.getCuota());
        }
        System.out.println("Administrativos:");
        for(Administrativo administrativo : administrativos){
            imprimirDatosPersona(administrativo);
            System.out.println(" horaDeEntrada: "+administrativo.getHoraDeEntrada()+" horaDeSalida: "+administrativo.getHoraDeSalida()
            +" sueldo: "+administrativo.getSueldo());
        }
        System.out.println("Docentes:");
        for(Docente docente : docentes){
            imprimirDatosPersona(docente);
            System.out.println(" materia: "+docente.getMateria()+" sueldo: "+docente.getSueldo());
        }
        System.out.println("Directivos:");
        for(Directivo directivo : directivos){
            imprimirDatosPersona(directivo);
            System.out.println(" cargoActual: "+directivo.getCargoActual()+" sueldo: "+directivo.getSueldo());
        }
    }
    /**
     * Permita obtener la cantidad de estudiantes discriminados según la cantidad de materias aprobadas 
     */
    public void imprimirCantidadDeEstudiantesPorMatAprob() {
        int[] cantidades = new int[50];
        for (int i = 0; i < 50; i++) {
            cantidades[i] = 0;
        } 
        for (Estudiante estudiante : estudiantes) {
            int materiasAprobadas = estudiante.getMateriasAprobadas();
            cantidades[materiasAprobadas]++;
        }
        System.out.println("Cantidad de estudiantes por cantidad de materias aprobadas:");
        for (int i = 0; i < 50; i++) {
            if (cantidades[i] > 0) {
                System.out.println(i + " materias aprobadas: " + cantidades[i]);
            }
        }
    }
    /**
     * Permite obtener los atributos de la clase padre enviandole parametros de la clse hija
     * @param Persona persona
     */
    private void imprimirDatosPersona(Persona p){
        System.out.print("Nombre: "+p.getNombre()+" DNI: "+p.getDni()
            +" fechaDeNacimiento: "+p.getFechaDeNacimiento()+" fechaDeIngreso: "+p.getFechaDeIngreso());
    }
}
