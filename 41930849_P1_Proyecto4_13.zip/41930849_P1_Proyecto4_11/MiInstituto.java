import java.util.*;
/**
 * Permita almacenar en 4 listas todas las personas(directivos, docentes, administrativos y estudiantes).
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class MiInstituto
{
    private ArrayList<Directivo> directivos;
    private ArrayList<Docente> docentes;
    private ArrayList<Administrativo> administrativos;
    private ArrayList<Estudiante> estudiantes;
    /**
     * Constructor que inicializa las 4 listas
     */
    public MiInstituto()
    {
        directivos = new ArrayList();
        docentes = new ArrayList();
        administrativos = new ArrayList();
        estudiantes = new ArrayList();
    }
    /**
     * Recibe un objeto de la clase correspondiente y lo agregua la lista respectiva.
     * @param Estudiante estudiante
     */
    public void agregarEstudiante(Estudiante estudiante){
        estudiantes.add(estudiante);
    }
    /**
     * Recibe un objeto de la clase correspondiente y lo agregua la lista respectiva.
     * @param Administrativo administrativo
     */
    public void agregarAdministrativo(Administrativo administrativo){
        administrativos.add(administrativo);
    }
    /**
     * Recibe un objeto de la clase correspondiente y lo agregua la lista respectiva.
     * @param Docente docente
     */
    public void  agregarDocente(Docente docente){
        docentes.add(docente);
    }
    /**
     * Recibe un objeto de la clase correspondiente y lo agregua la lista respectiva.
     * @param Directivo directivo
     */
    public void agregarDirectivo(Directivo directivo){
        directivos.add(directivo);
    }
    /**
     * Permite imprimir la cantidad de directivos, estudiantes, docentes y administrativos
     * almacenados en las listas.
     */
    public void imprimirCantidadDePersonasPorRol(){
        System.out.println("La cantidad de estudiantes es: "+estudiantes.size());
        System.out.println("La cantidad de administrativos es: "+administrativos.size());
        System.out.println("La cantidad de docentes es: "+docentes.size());
        System.out.println("La cantidad de directivos es: "+directivos.size());
    }
    /**
     * Permite imprimir todos los datos de todas las personas, recorriendo cada una de las listas.
     */
    public void imprimirTodosLosDatos(){
        System.out.println("Datos de las personas: ");
        System.out.println("Estudiantes:");
        //Recorre la clase estudiante y muestra sus atributo
        for(Estudiante estudiante : estudiantes){
            System.out.println("Nombre: "+estudiante.getNombre()+" DNI: "+estudiante.getDni()
            +" fechaDeNacimiento: "+estudiante.getFechaDeNacimiento()+" fechaDeIngreso: "+estudiante.getFechaDeIngreso()
            +" carrera: "+estudiante.getCarrera()+" materiasAprobadas: "+estudiante.getMateriasAprobadas()
            + " cuota: "+estudiante.getCuota());
        }
        System.out.println("Administrativos:");
        //Recorre la clase administrativo y muestra sus atributo
        for(Administrativo administrativo : administrativos){
            System.out.println("Nombre: "+administrativo.getNombre()+" DNI: "+administrativo.getDni()
            +" fechaDeNacimiento: "+administrativo.getFechaDeNacimiento()+" fechaDeIngreso: "+administrativo.getFechaDeIngreso()
            +" horaDeEntrada: "+administrativo.getHoraDeEntrada()+" horaDeSalida: "+administrativo.getHoraDeSalida()
            +" sueldo: "+administrativo.getSueldo());
        }
        System.out.println("Docentes:");
        //Recorre la clase docente y muestra sus atributo
        for(Docente docente : docentes){
            System.out.println("Nombre: "+docente.getNombre()+" DNI: "+docente.getDni()
            +" fechaDeNacimiento: "+docente.getFechaDeNacimiento()+" fechaDeIngreso: "+docente.getFechaDeIngreso()
            +" materia: "+docente.getMateria()+" sueldo: "+docente.getSueldo());
        }
        System.out.println("Directivos:");
        //Recorre la clase directivo y muestra sus atributo
        for(Directivo directivo : directivos){
            System.out.println("Nombre: "+directivo.getNombre()+" DNI: "+directivo.getDni()
            +" fechaDeNacimiento: "+directivo.getFechaDeNacimiento()+" fechaDeIngreso: "+directivo.getFechaDeIngreso()
            +" cargoActual: "+directivo.getCargoActual()+" sueldo: "+directivo.getSueldo());
        }
    }
    /**
     * Permita obtener la cantidad de estudiantes discriminados según la cantidad de materias aprobadas 
     */
    public void imprimirCantidadDeEstudiantesPorMatAprob() {
        int[] cantidades = new int[50];
        for (int i = 0; i < 50; i++) {
            cantidades[i] = 0;
        } 
        for (Estudiante estudiante : estudiantes) {
            int materiasAprobadas = estudiante.getMateriasAprobadas();
            cantidades[materiasAprobadas]++;
        }
        System.out.println("Cantidad de estudiantes por cantidad de materias aprobadas:");
        for (int i = 0; i < 50; i++) {
            if (cantidades[i] > 0) {
                System.out.println(i + " materias aprobadas: " + cantidades[i]);
            }
        }
    }
}
