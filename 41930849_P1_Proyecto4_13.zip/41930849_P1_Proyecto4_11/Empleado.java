
/**
 * Clase que contiene los atributos de un empleado
 * 
 * @author Lucas Nuñez 
 * @version 1.0
 */
public class Empleado extends Persona
{
    private double sueldo;

    /**
     * Constructor que crea una instancia de la clase Empleado
     */
    public Empleado()
    {
       super(); 
    }
    /**
     * Metodo que permite ingresar un sueldo
     * @param double nuevoSueldo
     */
    public void setSueldo(double nuevoSueldo){
        this.sueldo = nuevoSueldo;
    }
    /**
     * Metodo que retorna un sueldo
     * @return double sueldo
     */
    public double getSueldo(){
        return sueldo;
    }
    
}
