
/**
 * Clase docenten que cuenta con las caracteristicas de un docente
 * 
 * @author Lucas Nuñez 
 * @version 1.0
 */
public class Docente extends Empleado
{
    private String materia;
    /**
     * Constructor que inicializa una instancia de la clase
     */
    public Docente()
    {
        super();
        
    }
    /**
     * Metodo que  permite ingresar una materia
     * @param String nombreMateria
     */
    public void setMateria(String nombreMateria){
        this.materia = nombreMateria;
    }
    /**
     * Metodo que retorna una materia
     * @return String materia
     */
    public String getMateria(){
        return materia;
    }
    
}
