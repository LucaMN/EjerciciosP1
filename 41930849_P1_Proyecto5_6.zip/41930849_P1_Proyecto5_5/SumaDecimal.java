
/**
 * clase de nombre “SumaDecimal” que es clase hija de la clase “Calculo”,
 * que permita realizar la suma de números decimales.
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class SumaDecimal extends Calculo
{
    
    /**
     * Constructor de objectos de la clase  SumaDecimal
     */
    public SumaDecimal()
    {
        
    }
    
    /**
     * Metodo de nombre “sumar” que recibe como parámetros 2 “Object", los suma e imprime el mensaje
     * @param Object numero1
     * @param Object numero2
     */
    public void sumar(Object numero1, Object numero2){
        double num1 = (double) numero1;
        double num2 = (double) numero2;
        System.out.println("Resultado de la suma de dos números enteros es: "+(num1+num2));
    }
}
