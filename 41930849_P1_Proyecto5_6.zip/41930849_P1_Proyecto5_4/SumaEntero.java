
/**
 * clase de nombre “SumaEntero” que es clase hija de la clase “Calculo”,
 * que permita realizar la suma de números enteros.
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class SumaEntero extends Calculo
{
    /**
     * Constructor de objectos de la clase SumaEntero
     */
    public SumaEntero()
    {
        
    }
    /**
     * Metodo de nombre “sumar” que recibe como parámetros 2 “Object", los suma e imprime el mensaje
     * @param Object numero1
     * @param Object numero2
     */
    public void sumar(Object numero1, Object numero2){
        int num1 = (int) numero1;
        int num2 = (int) numero2;
        System.out.println("Resultado de la suma de dos números enteros es: "+(num1+num2));
    }
    
}
