
/**
 * clase de nombre “Suma” que permita realizar la suma de 2 números enteros o 2 números condecimales.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Suma 
{
    /**
     * Constructor de objectos de la clase Suma
     */
    public Suma()
    {
        
    }
    /**
     * Metodo sumar que realiza la suma e imprime el resultado de la misma
     * @param int numero1 numero entero
     * @param int numero2 numero entero
     */
    public void sumar(int numero1, int numero2){
        System.out.println("Resultado de la suma de dos números enteros: "+(numero1+numero2));
    }
    /**
     * Metodo sumar que raliza la suma e imprime el resultado de la misma
     * @param double numero1 numero con decimal
     * @param double numero2 numero con decimal
     */
    public void sumar(double numero1, double numero2){
        System.out.println("Resultado de la suma de dos números con decimales: "+(numero1+numero2));
    }
    
}
