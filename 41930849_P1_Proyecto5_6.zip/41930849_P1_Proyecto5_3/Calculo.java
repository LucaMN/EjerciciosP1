
/**
 * clase de nombre “Calculo” que solamente servira de superclase para dos clases que “especializarán” el cálculo,
 * realizando la suma de números enteros por un lado y de números con decimales por otro.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Calculo
{
    /**
     * Constructor de objectos de la clase Calculo
     */
    public Calculo()
    {
        
    }
    /**
     * Metodo sumar que recibe como parámetros 2 “Object” y no tiene implementación (sin instrucciones).
     * @param Object numero1 
     * @param Object numero2
     */
    public void sumar(Object numero1, Object numero2){
    
    }
    
}
