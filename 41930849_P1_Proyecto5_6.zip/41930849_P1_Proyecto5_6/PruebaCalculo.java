
/**
 * Clase PruebaCalculo que sirve para probar las clases "SumaDecimal", "SumaEntero" y "Calculo",
 * que realiza la suma de 2 números enteros y 2 números con decimales.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class PruebaCalculo
{
    
    /**
     * Constructor de objetos de la clase  PruebaCalculo
     */
    public PruebaCalculo()
    {
        Calculo calculo1 = new SumaEntero();
        Calculo calculo2 = new SumaDecimal();
        
        calculo1.sumar(1,2);
        calculo2.sumar(1.11,2.22);
    }

    
}
