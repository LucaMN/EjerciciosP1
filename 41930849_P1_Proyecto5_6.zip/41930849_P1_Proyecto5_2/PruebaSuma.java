
/**
 * clase PruebaSuma que realiza pruebas sobre la clase Suma.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class PruebaSuma
{
    
    /**
     * Constructor de objectos de la clase PruebaSuma
     */
    public PruebaSuma()
    {
        Suma suma = new Suma();
        suma.sumar(1,2);
        suma.sumar(1.11,2.22);
    }

    
}
