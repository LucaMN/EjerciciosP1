
/**
 * Esta clase recibe un numero que no se puede sobrepasar de ciertos limites y los almacena con hasta 2 decimas
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class Numero6E2D
{
    //Variable de instancia que almacena un valor double.
    private double numero;
    //Variable de clase que define los limites.
    private final static double LIMITE_MAXIMO = 999999.99;
    private final static double LIMITE_MINIMO = -999999.99;

    /**
     * Constructor que crea una instancia de la clase.
     */
    public Numero6E2D()
    {
        this.numero = 0;
    }
    /**
     * Metodo que retorna el valor de una variable.
     * @return double LIMITE_MAXIMO.
     */
    public double getNumeroMaximo(){
        return LIMITE_MAXIMO;
    }
    /**
     * Metodo que retorna el valor de una variable.
     * @return double numero.
     */
    public double getNumero(){
        return numero;
    }
    /**
     * Metodo que almacena el valor de una variable si cumple cierto requisito
     * @param double nuevoNumero
     * @return true si el parametro cumple los requisitos
     *         false si el parametro no cumple los requisitos
     */
    public boolean setNumero(double nuevoNumero){
        if(nuevoNumero >= LIMITE_MINIMO && nuevoNumero <= LIMITE_MAXIMO){
            nuevoNumero = Math.round(nuevoNumero * 100d) / 100d;
            this.numero = nuevoNumero;
            return true;
        }
        return false;
    }
}
