
/**
 * Clase que realiza diferentes pruebas a la clase Numero6E2D.
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class PruebaNumero6E2D
{
    

    /**
     * Constructor que inicia una instancia de la clase PruebaNumero6E2D.
     */
    public PruebaNumero6E2D()
    {
        Numero6E2D prueba1 = new Numero6E2D();
        Numero6E2D prueba2 = new Numero6E2D();
        Numero6E2D prueba3 = new Numero6E2D();
        
        
        System.out.println(prueba1.setNumero(123456.789));
        System.out.println(prueba1.getNumero());
        
        System.out.println(prueba2.setNumero(1234567.89));
        System.out.println(prueba2.getNumero());
        
        System.out.println(prueba2.setNumero(-0.789));
        System.out.println(prueba2.getNumero());
        
        double suma = prueba2.getNumero() + prueba1.getNumero();
        
        System.out.println(prueba3.setNumero(suma));
        
        System.out.println(prueba1.setNumero(-999999.989));
        System.out.println(prueba1.getNumero());
        
        double suma2 = prueba1.getNumero() + prueba2.getNumero();
        
        System.out.println(prueba3.setNumero(suma2));
        
        System.out.println(prueba1.getNumeroMaximo());
    }
        

    
}
