/**
 * Perro nos va a imprimir un cadena que nos mostrara su nombre y edad
 * @author Lucas Nuñez
 * @version (1.0)
 */

public class Perro
{
    private String nombre;
    private int edad;
    /**
     * Crea un Perro y lo inicializa con una edad  y nombre
     */
    public Perro()
    {
        this.edad=0;
        this.nombre=null;
    }
    /**
     * Metodo que permite ingresarle  un valor al atributo nombre
     * @param nombrePerro recibe el nombre del Perro
     */
    public void setNombre(String nombrePerro){
        nombre = nombrePerro;
    }
    /**
     * Metodo que permite retornar el nombre del Perro
     * @return nombre retornara el nombre actual del Perro
     */
    public String getNombre(){
        return nombre;
    }
    /**
     * Metodo que permite ingresarle un valor al atributo edad
     * @param edadPerro recibe el nombre del Perro
     */
    public void setEdad(int edadPerro){
        edad = edadPerro;
    }
    /**
     * Metodo que permite retornar la edad del Perro
     * @return edad retornara la edad del Perro
     */
    public int getEdad(){
        return edad;
    }
    /**
     * Metodo que imprime una cadena con los valores del nombre y edad del Perro
     */
    public void imprimirDatos(){
        System.out.println("El nombre del perro es "+getNombre()+" y tiene "+getEdad()+" años");
    }
}
