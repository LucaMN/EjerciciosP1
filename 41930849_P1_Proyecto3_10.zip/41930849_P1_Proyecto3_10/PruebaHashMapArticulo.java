import java.util.HashMap;
import java.util.*;
/**
 * Clase que realiza pruebas a la clase HashMapArticulo
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class PruebaHashMapArticulo
{
    
    private HashMapArticulo prueba = new HashMapArticulo();
    /**
     * Constructor que crea una instancia de la clase
     */
    public PruebaHashMapArticulo()
    {
        prueba.agregarArticulo(1, "Yerba");
        prueba.agregarArticulo(2, "Azucar");
        prueba.agregarArticulo(3, "Pan");
        
        
        System.out.println(prueba.obtenerTamanio());
        System.out.println(prueba.buscarArticulo(2));
        
        for (Object clave:prueba.getArticulos().keySet()) {
            System.out.print(clave);
            System.out.println(prueba.getArticulos().get(clave));
        }
        
        Iterator<HashMap.Entry<Integer, String>> iterator = prueba.getArticulos().entrySet().iterator();
        while(iterator.hasNext()){
            HashMap.Entry<Integer, String> entry = iterator.next();
            System.out.println(entry.getKey() + entry.getValue());
        }
        
    }
}

    
    
    

