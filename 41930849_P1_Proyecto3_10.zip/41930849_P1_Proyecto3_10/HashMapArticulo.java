import java.util.*;
/**
 * Clase que crea un HashMap y le almacena clave/valor.
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class HashMapArticulo
{
    private HashMap <Integer, String> map;
    /**
     * Constructor que inicializa una instancia de la clase
     */
    public HashMapArticulo()
    {
       map = new HashMap <Integer, String> ();
    }
    /**
     * Metodo que permite agregar articulos al HashMap.
     * @param Integer clave
     * @param String artc
     */
    public void agregarArticulo(Integer clave, String artc){
        map.put(clave, artc);
    }
    /**
     * Metodo que retorna el HashMap
     * @return HashMap map
     */
    public HashMap getArticulos(){
        return map;
    }
    /**
     * Metodo que retorna el tamaño del HashMap
     * @return int map
     */
    public int obtenerTamanio(){
        return map.size();
    }
    /**
     * Metodo que permite buscar un articulo con la clave
     * @param Integer clave
     * @return String articulo correspondiente a la clave ingresada
     */
    public String buscarArticulo(Integer clave){
        map.containsKey(clave);
        return map.get(clave);
    }
}
