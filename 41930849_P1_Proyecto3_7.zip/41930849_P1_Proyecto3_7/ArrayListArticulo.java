import java.util.*;
/**
 * Clase que crea un arrayList y le almacena objetos.
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class ArrayListArticulo
{
    private ArrayList <String>articulos;
    /**
     * Constructor que inicializa una instancia de la clase
     */
    public ArrayListArticulo()
    {
       articulos = new ArrayList();
    }
    /**
     * Metodo que permite agregar articulos al arrayList.
     * @param String nuevoArtc
     */
    public void agregarArticulo(String nuevoArtc){
        articulos.add(nuevoArtc);
    }
    /**
     * Metodo que retorna el arrayList
     * @return arrayList articulos
     */
    public ArrayList getArticulos(){
        return articulos;
    }
    /**
     * Metodo que retorna el tamaño del arrayList
     * @return int articulos
     */
    public int obtenerTamanio(){
        return articulos.size();
    }
    
}
