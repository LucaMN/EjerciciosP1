import java.util.*;
/**
 * Clase que realiza pruebas a la clase ArrayListArticulo
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class PruebaArrayArticulo
{
    
    private ArrayListArticulo prueba = new ArrayListArticulo();
    /**
     * Constructor que crea una instancia de la clse
     */
    public PruebaArrayArticulo()
    {
        prueba.agregarArticulo("Yerba");
        prueba.agregarArticulo("Azucar");
        prueba.agregarArticulo("Pan");
        
        
        System.out.println(prueba.obtenerTamanio());
        
        for (Object i : prueba.getArticulos()) {
            if(i==null) {
               break;
            }else{
            System.out.println(i);
            }
        }
        
        Iterator<String> it = prueba.getArticulos().iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
        
    }
}

    
    
    

