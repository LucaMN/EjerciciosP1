
/**
 * Clase que almacena los valores de un billete
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Billete extends Dinero
{
    //variable de instancia que contiene la numeración del billete
    private String numeración;

    /**
     * Constructor de objetos de la clase Billete
     */
    public Billete()
    {
        super();
        
    }
    /**
     * Retorna la numeración del billete
     * @return String numeración
     */
    public String getNumeración(){
        return numeración;
    }
    /**
     * Almacena la numeracion de un billete
     * @para String nuevaNumeracion;
     */
    public void setNumeración(String nuevaNumeración){
        this.numeración=nuevaNumeración;
    }
    
}
