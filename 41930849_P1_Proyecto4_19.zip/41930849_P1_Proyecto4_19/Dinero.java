
/**
 * Write a description of class Dinero here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Dinero
{
    // instance variables - replace the example below with your own
    private double valor;
    private String nombre;
    /**
     * Constructor for objects of class Dinero
     */
    public Dinero()
    {
        // initialise instance variables
        
    }
    public double getValor(){
        return valor;
    }
    public void setValor(double nuevoValor){
        this.valor=nuevoValor;
    }
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nuevoNombre){
        this.nombre=nuevoNombre;
    }
    
}
