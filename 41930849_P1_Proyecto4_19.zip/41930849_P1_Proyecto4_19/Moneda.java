
/**
 * Clase que almacena los valores de una moneda.
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Moneda extends Dinero
{
    //variable de instancia que contiene el valor del año en que fue creada la moneda
    private int año;
    /**
     * Constructor de objetos de la clase Moneda
     */
    public Moneda()
    {
        super();
        
    }
    /**
     * Retorna el año en que fue creada la moneda
     * @return int año
     */
    public int getAño(){
        return año;
    }
    /**
     * Almacena el año en que fue creada la moneda
     * @param int nuevoAño
     */
    public void setAño(int nuevoAño){
        this.año=nuevoAño;
    }
    
}
