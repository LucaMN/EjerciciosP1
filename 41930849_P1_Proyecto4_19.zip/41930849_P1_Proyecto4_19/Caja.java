
import java.util.*;
/**
 * permite almacenar todo el dinero disponible (billetes y monedas).
 * 
 * @author (Lucas Nuñez) 
 * @version (1.0)
 */
public class Caja
{
    //ArrayList de tipo  Moneda y Billete
    private ArrayList<Moneda> monedas;
    private ArrayList<Billete> billetes;

    /**
     * Constructor de objetos de la clase Caja
     */
    public Caja()
    {
        //Inicializamos los ArrayList
        billetes = new ArrayList<>();
        monedas = new ArrayList<>();
    }
    /**
     * Recibe un objeto de la clase Billete y lo agregue a la lista.
     */
    public void agregarBillete(Billete billete){
        billetes.add(billete);
    }
    /**
     * Recibe un objeto de la clase Moneda y lo agregue a la lista.
     */
    public void agregarMoneda(Moneda moneda){
        monedas.add(moneda);
    }
    /**
     * Permita imprimir el monto total de dinero en dólares que contiene la caja 
     */
    public void contarDolares(){
        //variable que alamcenara la cantidad
        double contarBilletes=0;
        //Recorremos el ArrayList con un for each
        for(Billete billete : billetes){
            //Si el billete tiene como nombre dolar obtenemos su valor y lo almacenamos
            if(billete.getNombre().equals("dolar")){
                contarBilletes = contarBilletes+billete.getValor();
            }
        }
        //Recorremos el ArrayList con un for each
        for(Moneda moneda : monedas){
            //Si la moneda tiene como nombre dolar obtenemos su valor y lo almacenamos
            if(moneda.getNombre().equals("dolar")){
                contarBilletes = contarBilletes+moneda.getValor();
            }
        }
        //Mostramos el monto total de dinero con nombre dolar
        System.out.println("El monto total de dinero en dolares es...: $"+contarBilletes);
    }
    /**
     * Permita contar cuantas monedas con año menor a 2000 existen en la caja
     */
    public void buscarMonedas(){
        //Variable que contara las monedas
        int contarMonedas=0;
        //Recorremos el ArrayList monedas con un for each 
        for(Moneda moneda : monedas){
            //Si la moneda tiene como valor un año menor a 2000 la contamos
            if(moneda.getAño()< 2000){
                contarMonedas++;
            }
        }
        //Mostramos cuantas monedas tiene un año menor a 2000
        System.out.println("Existen "+contarMonedas+" monedas con año menor a 2000");
    }
}
