
/**
 * Esta clase permitirá modelar un docente,utiliza
 * como superclase a la clase Empleado.
 * 
 * @author (Lucas Nuñez) 
 * @version (V2)
 */
public class Docente extends Empleado
{
    // definición de variables de instancia
    private String materia;
    
    /**
     * Constructor de objetos de la clase Docente
     */
    public Docente()
    {
        super();
    }

    /**
     * Método setMateria
     * 
     * @param  String materia La materia que dicta el docente
     */
    public void setMateria(String materia)
    {
        this.materia = materia;
    }

    
    /**
     * Método getMateria
     * 
     * @return  String  La materia que dicta el docente
     */
    public String getMateria()
    {
        return materia;
    }
    /**
     *Retorna una cadena con la misma información que imprime actualmente el método “imprimirTodosLosDatos” de la clase MiInstituto
     *@return String texto con información sobre el docente
     *@Override
     */
    public String toString(){
        return super.toString()+" Materia: "+this.materia;
    }
}
