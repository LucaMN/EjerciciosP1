
/**
 * Esta clase permitirá modelar un estudiante, utiliza
 * como superclase a la clase Persona
 * 
 * @author (Lucas Nuñez) 
 * @version (V1)
 */
public class Estudiante extends Persona
{
    // definición de variables de instancia
    private String carrera;
    private int cantMatAprob;
    private double importeCuota;
    // definición de variable de clase
    private static final String QUE_SOY ="estudiante";    
    /**
     * Constructor de objetos de la clase Estudiante
     */
    public Estudiante()
    {
        super();
    }

    /**
     * Método setCarrera
     * 
     * @param  String carrera La carrera que sigue el estudiante
     */
    public void setCarrera(String carrera)
    {
        this.carrera = carrera;
    }

    /**
     * Método setCantidadMateriasAprobadas
     * 
     * @param  int cantMatAprob La cantidad de materias aprobadas
     *                          por el estudiante
     */
    public void setCantidadMateriasAprobadas(int cantMatAprob)
    {
        this.cantMatAprob = cantMatAprob;
    }

    /**
     * Método setImporteCuota
     * 
     * @param  double importeCuota El importe de la cuota que debe
     *                             abonar el estudiante
     */
    public void setImporteCuota(double importeCuota)
    {
        this.importeCuota = importeCuota;
    }

    
    /**
     * Método getCarrera
     * 
     * @return  String La carrera que sigue el estudiante
     */
    public String getCarrera()
    {
        return carrera;
    }

    /**
     * Método getCantidadMateriasAprobadas
     * 
     * @return  int  La cantidad de materias aprobadas
     *               por el estudiante
     */
    public int getCantidadMateriasAprobadas()
    {
        return cantMatAprob;
    }

    /**
     * Método getImporteCuota
     * 
     * @return  double El importe de la cuota que debe
     *                 abonar el estudiante
     */
    public double getImporteCuota()
    {
        return importeCuota;
    }   
    /**
     *Retorna una cadena con la misma información que imprime actualmente el método “imprimirTodosLosDatos” de la clase MiInstituto
     *@return String texto con información sobre el estudiante
     *@Override
     */
    public String toString(){
        return super.toString()+" Carrera: "+this.carrera+"\n"+
                                " Materias aprobadas: "+this.cantMatAprob+"\n"+
                                " Cuota: "+this.importeCuota;
    }
    /**
     *Retorna el rol que cumple la clase.
     *@return String rol de la clase.
     */
    public String queSoy(){
            return QUE_SOY;
    }
}
