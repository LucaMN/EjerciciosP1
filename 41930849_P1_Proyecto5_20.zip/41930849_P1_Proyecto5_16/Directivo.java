/**
 * Esta clase permitirá modelar un empleado 
 * directivo, utiliza
 * como superclase a la clase Empleado.
 * 
 * @author (Lucas Nuñez) 
 * @version (V2)
 */
public class Directivo extends Empleado
{
    // definición de variables de instancia
    private String cargo;
    // definición de variable de clase
    private static final String  QUE_SOY = "directivo";
    /**
     * Constructor de objetos de la clase Directivo
     */
    public Directivo()
    {
        super();
    }

    /**
     * Método setCargo
     * 
     * @param  String cargo El cargo que ocupa el directivo
     */
    public void setCargo(String cargo)
    {
        this.cargo = cargo;
    }

    
    /**
     * Método getCargo
     * 
     * @return  String  El cargo que ocupa el directivo
     */
    public String getCargo()
    {
        return cargo;
    }
    /**
     *Retorna una cadena con la misma información que imprime actualmente el método “imprimirTodosLosDatos” de la clase MiInstituto
     *@return String texto con información sobre el directivo
     *@Override 
     */
    public String toString(){
        return super.toString()+" Cargo: "+this.cargo;
    }
    /**
     *Retorna el rol que cumple la clase.
     *@return String rol de la clase.
     */
    public String queSoy(){
            return QUE_SOY;
    }
}
