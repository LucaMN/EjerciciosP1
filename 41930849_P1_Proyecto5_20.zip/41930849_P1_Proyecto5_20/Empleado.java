/**
 * La clase Empleado deriva de Persona y permitirá
 * agrupar a todas las personas que cobran sueldo 
 * (administrativos, docentes, etc.).
 * 
 * @author (Lucas Nuñez) 
 * @version (V1)
 */
public class Empleado extends Persona
{
    // definición de variables de instancia
    private double sueldoMensual;
    //definición de variable de clase
    private static final String QUE_SOY ="empleado";
    /**
     * Constructor de objetos de la clase Empleado
     */
    public Empleado()
    {
        super();
    }

    /**
     * Método setSueldoMensual
     * 
     * @param  double sueldoMensual El sueldo mensual del docente
     */
    public void setSueldoMensual(double sueldoMensual)
    {
        this.sueldoMensual = sueldoMensual;
    }

    
    /**
     * Método getSueldoMensual
     * 
     * @return  double  El sueldo mensual del docente
     */
    public double getSueldoMensual()
    {
        return sueldoMensual;
    }  
    /**
     *Retorna una cadena con la misma información que imprime actualmente el método “imprimirTodosLosDatos” de la clase MiInstituto
     *@return String texto con información sobre el empleado
     *@Override
     */
    public String toString(){
        return super.toString()+" Sueldo: "+this.sueldoMensual;
    }
    /**
     *Retorna el rol que cumple la clase.
     *@return String rol de la clase.
     */
    public String queSoy(){
            return QUE_SOY;
    }
    
}