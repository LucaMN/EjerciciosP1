
/**
 * Esta clase permitirá modelar las diferente "personas"
 * que interactúan. Actuará de superclase
 * para las clases Docente, Estudiante, etc.
 * 
 * @author (Lucas Nuñez) 
 * @version (V1)
 */
public class Persona
{
    // definición de variables de instancia
    private String nombre;
    private int dni;
    private String fechaNac;
    private String fechaIng;
    
    /**
     * Constructor de objetos de la clase Persona
     */
    public Persona()
    {
    }

    /**
     * Método setNombre
     * 
     * @param  String nombre El nombre de la persona
     */
    public void setNombre(String nombre)
    {
        this.nombre = nombre;
    }

    /**
     * Método setDni
     * 
     * @param  int dni El dni de la persona
     */
    public void setDni(int dni)
    {
        this.dni = dni;
    }

    /**
     * Método setFechaDeNacimiento
     * 
     * @param  String fechaNac La fecha de nacimiento de la persona
     */
    public void setFechaDeNacimiento(String fechaNac)
    {
        this.fechaNac = fechaNac;
    }

    /**
     * Método setFechaDeIngreso
     * 
     * @param  String fechaIng La fecha de ingreso de la persona
     */
    public void setFechaDeIngreso(String fechaIng)
    {
        this.fechaIng = fechaIng;
    }

    
    /**
     * Método getNombre
     * 
     * @return  String  El nombre de la persona
     */
    public String getNombre()
    {
        return nombre;
    }

    /**
     * Método getDni
     * 
     * @return  int  El dni de la persona
     */
    public int getDni()
    {
        return dni;
    }

    /**
     * Método getFechaDeNacimiento
     * 
     * @return  String  La fecha de nacimiento de la persona
     */
    public String getFechaDeNacimiento()
    {
        return fechaNac;
    }

    /**
     * Método getFechaDeIngreso
     * 
     * @return  String  La fecha de ingreso de la persona
     */
    public String getFechaDeIngreso()
    {
        return fechaIng;
    }
    /**
     *Retorna una cadena con la misma información que imprime actualmente el método “imprimirTodosLosDatos” de la clase MiInstituto
     *@return String texto con información sobre la persona
     *@Override
     */
    public String toString(){
        return "Nombre : "+ this.nombre+ "\n"+
               "Dni  : "+ this.dni+"\n"+
               "Fecha de nacimiento: "+this.fechaNac+"\n"+
               "Fecha de ingreso: "+this.fechaIng+"\n";
    }
    
}