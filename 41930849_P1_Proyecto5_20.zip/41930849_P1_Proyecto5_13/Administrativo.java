
/**
 * Esta clase permitirá modelar un empleado 
 * administrativo, utiliza
 * como superclase a la clase Empleado.
 * 
 * @author (Lucas Nuñez) 
 * @version (V2)
 */
public class Administrativo extends Empleado
{
    // definición de variables de instancia
    private int horaEntrada;
    private int horaSalida;
    
    /**
     * Constructor de objetos de la clase Administrativo
     */
    public Administrativo()
    {
        super();
    }

    /**
     * Método setHoraEntrada
     * 
     * @param  int horaEntrada La hora de entrada del administrativo
     */
    public void setHoraEntrada(int horaEntrada)
    {
        this.horaEntrada = horaEntrada;
    }

    /**
     * Método setHoraSalida
     * 
     * @param  int horaSalida La hora de salida del administrativo
     */
    public void setHoraSalida(int horaSalida)
    {
        this.horaSalida = horaSalida;
    }

    
    /**
     * Método getHoraEntrada
     * 
     * @return  int  La hora de entrada del administrativo
     */
    public int getHoraEntrada()
    {
        return horaEntrada;
    }

    /**
     * Método getHoraSalida
     * 
     * @return  int  La hora de salida del administrativo
     */
    public int getHoraSalida()
    {
        return horaSalida;
    }    
    /**
     *Retorna una cadena con la misma información que imprime actualmente el método “imprimirTodosLosDatos” de la clase MiInstituto
     *@return String texto con información sobre el administrativo
     *@Override 
     */
    public String toString(){
        return super.toString()+" Hora de entrada: "+this.horaEntrada+"\n"+
                                " Hora de salida: "+this.horaSalida;
    }
    
}