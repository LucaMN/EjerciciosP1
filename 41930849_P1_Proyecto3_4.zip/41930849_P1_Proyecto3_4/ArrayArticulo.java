
/**
 * Clase que crea un array y le almacena objetos.
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class ArrayArticulo
{
    private String articulos[];
    private int contador;
    /**
     * Constructor que inicializa una instancia de la clase
     */
    public ArrayArticulo()
    {
       articulos = new String[1000];
    }
    /**
     * Metodo que permite agregar articulos al array.
     * @param String nuevo Artc
     */
    public void agregarArticulo(String nuevoArtc){
        articulos[contador]=nuevoArtc;
        contador++;
    }
    /**
     * Metodo que retorna el array
     * @return articulos[]
     */
    public String[] getArticulos(){
        return articulos;
    }
    /**
     * Metodo que retorna el tamaño del array
     * @return int contador
     */
    public int obtenerTamanio(){
        return contador;
    }
    
}
