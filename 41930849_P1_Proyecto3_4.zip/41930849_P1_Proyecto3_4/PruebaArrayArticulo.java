import java.util.*;
/**
 * Clase que realiza pruebas a la clase ArrayArticulo
 * 
 * @author Lucas Nuñez
 * @version 1.0
 */
public class PruebaArrayArticulo
{
    
    private ArrayArticulo prueba = new ArrayArticulo();
    /**
     * Constructor que crea una instancia de la clse
     */
    public PruebaArrayArticulo()
    {
        prueba.agregarArticulo("Yerba");
        prueba.agregarArticulo("Azucar");
        prueba.agregarArticulo("Pan");
        
        System.out.println(prueba.obtenerTamanio());
        
        for (String i : prueba.getArticulos()) {
            if(i==null) {
               break;
            }else{
            System.out.println(i);
            }
        }
        
        for(int n=0;n <prueba.getArticulos().length;n++){
            if(prueba.getArticulos()[n] == null){
                break;
            }else{
                System.out.println(prueba.getArticulos()[n]);
            }
        }
    }

    
    
    
}
